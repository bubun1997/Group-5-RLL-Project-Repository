package com.mycompany.app;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.mycompany.app.model.User;
import com.mycompany.app.userdao.UserDao;

@SpringBootTest
class HouseKeeperSchedulingSystemApplicationTests {
	
	@Autowired
	private UserDao dao;
	
	@Test
	@Transactional
	void contextLoads() {
		
		List<User> users = dao.findAll();
		
		for(User u:users) {
			
			System.out.println(u.getFullName());
			System.out.println(u.getHousekeepers());
		}
	}

}
