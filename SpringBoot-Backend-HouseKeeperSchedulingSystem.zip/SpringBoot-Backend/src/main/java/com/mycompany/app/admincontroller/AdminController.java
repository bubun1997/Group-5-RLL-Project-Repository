package com.mycompany.app.admincontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycompany.app.adminservice.AdminService;
import com.mycompany.app.housekeeperservice.HouseKeeperService;
import com.mycompany.app.model.Admin;
import com.mycompany.app.model.HouseKeeper;
import com.mycompany.app.model.User;
import com.mycompany.app.userdao.UserDao;
import com.mycompany.app.userservice.UserService;

@RestController
@RequestMapping("/api/admin/myapp")
public class AdminController {
   
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private HouseKeeperService houseKeeperService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDao dao;
	
	@GetMapping("/get/all/housekeepers")
	public ResponseEntity<?> getAllHouseKeepers(){
		
		List<HouseKeeper> houseKeepers = this.houseKeeperService.getAllHouseKeepers();
		if(houseKeepers.isEmpty()) {
			
			return new ResponseEntity<String>("No housekeepers are avialble !!",HttpStatus.OK);
		}
		
		return new ResponseEntity<List<HouseKeeper>>(houseKeepers,HttpStatus.OK);
	}
	
	@GetMapping("/get/users")
	public ResponseEntity<List<User>> getAllStudents(){
		return new ResponseEntity<List<User>>(this.dao.findAll(),HttpStatus.OK);
	}
	
	@PostMapping("/register/admin")
	public ResponseEntity<?> registerAdmin(@RequestBody Admin admin){
		
		Admin regAdmin = this.adminService.registerAdmin(admin);
		if(regAdmin != null) {
			
			return new ResponseEntity<Admin>(regAdmin,HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("Username already exists !!",HttpStatus.BAD_REQUEST);
	}
	@PostMapping("/admin/login")
	public ResponseEntity<?> validateAdminLogin(@RequestBody Admin admin) {
		
		 Admin myAdmin = this.adminService.validateAdminLogin(admin.getAdminUserName(), admin.getAdminPassword());
		 
		 
		 if(myAdmin != null) {
			 
			 return new ResponseEntity<Admin>(myAdmin,HttpStatus.FOUND);
		 }
		 
		 return new ResponseEntity<String>("Invalid credentials !!",HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/register/housekeeper")
	public ResponseEntity<?> addHouseKeeper(@RequestBody HouseKeeper houseKeeper){
		
		HouseKeeper keeper = this.houseKeeperService.registerHouseKeeper(houseKeeper);
		
		if(keeper != null) {
			
			return new ResponseEntity<HouseKeeper>(keeper,HttpStatus.CREATED);
			 
		}
		 return new ResponseEntity<String>("Housekeeper not registered !!",HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("/allot/keeper/{uid}/{hkid}")
	public ResponseEntity<String> allotKeeper(@PathVariable("uid") Long uid,@PathVariable("hkid")Long hkid){
		
		User user = this.userService.findUserById(uid);
		
		HouseKeeper keeper = this.houseKeeperService.findHoseKeeperById(hkid);
		
		if(user!=null && keeper!=null) {
			
			user.setHousekeepersForSpecificUser(keeper);
			keeper.setUser(user);
			
			this.userService.saveUser(user);
			this.houseKeeperService.registerHouseKeeper(keeper);
			
			return new ResponseEntity<String>("Housekeeper allotted",HttpStatus.OK);

		}
		
		return new ResponseEntity<String>("Housekeeper not allotted",HttpStatus.BAD_REQUEST);

	}
	
	@PutMapping("/update/housekeeper")
	public ResponseEntity<String> updateHouseKeeper(@RequestBody HouseKeeper keeper){
		
		HouseKeeper newKeeper = this.houseKeeperService.updateHouseKeeper(keeper);
		
		if(newKeeper != null) {
			
			return new ResponseEntity<String>("Updated",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Not Updated",HttpStatus.NOT_MODIFIED);

		
		
	}
	
}
