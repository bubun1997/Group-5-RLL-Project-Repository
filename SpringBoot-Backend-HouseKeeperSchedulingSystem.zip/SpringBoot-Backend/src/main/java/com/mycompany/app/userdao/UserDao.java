package com.mycompany.app.userdao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mycompany.app.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Long>{
	
	@Query("SELECT user FROM User user where user.userName = ?1 and user.userPassword = ?2")
	User validateUserLogin(String uname,String pass);
	
	@Query("SELECT user from User user where user.userName = ?1")
	User checkUserAvilability(String uname);
	
	
	@Modifying
	@Query("Update User u set u.userPassword = ?2 WHERE u.userName = ?1")
	@Transactional
	int updatePassword(String uname,String password);
	
	

}
