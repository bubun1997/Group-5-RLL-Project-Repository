package com.mycompany.app.adminservice;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.app.admindao.AdminDao;
import com.mycompany.app.model.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao adminDao;
	
	@Override
	public Admin registerAdmin(Admin admin) {
		
		Admin availableAdmin = this.checkAdminAvailability(admin.getAdminUserName());
		
		if(availableAdmin != null) {
			
			return null;
		

			
		}
		return this.adminDao.save(admin);

	}

	@Override
	public Admin validateAdminLogin(String uname,String pass) {
		
		
		return this.adminDao.validateAdminLogin(uname,pass);
		
		
	}

	@Override
	public Admin checkAdminAvailability(String uname) {
		
		return this.adminDao.checkAdminAvailability(uname);
	}

	
}
