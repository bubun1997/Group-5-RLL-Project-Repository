package com.mycompany.app.adminservice;


import com.mycompany.app.model.Admin;

public interface AdminService {
	
	Admin registerAdmin(Admin admin);
	 
	Admin checkAdminAvailability(String uname);
	
	Admin validateAdminLogin(String uname,String pass);

}
