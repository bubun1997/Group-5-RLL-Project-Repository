package com.mycompany.app.admindao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mycompany.app.model.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin, Long> {
	
	@Query("SELECT admin from Admin admin where admin.adminUserName = ?1 and admin.adminPassword = ?2")
	Admin validateAdminLogin(String uname,String pass);
	
	@Query("SELECT admin from Admin admin where admin.adminUserName = ?1")
	Admin checkAdminAvailability(String uname);
}
