package com.mycompany.app.housekeeperservice;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.app.housekeeperdao.HouseKeeperDao;
import com.mycompany.app.model.HouseKeeper;

@Service
public class HouseKeeperServiceImpl implements HouseKeeperService {

	@Autowired
	private HouseKeeperDao houseKeeperDao;
	
	@Override
	public HouseKeeper findHoseKeeperById(Long id) {
		
		return this.houseKeeperDao.findById(id).orElse(null);
	}

	@Override
	public HouseKeeper registerHouseKeeper(HouseKeeper houseKeeper) {
		return this.houseKeeperDao.save(houseKeeper);
	}

	@Override
	public HouseKeeper updateHouseKeeper(HouseKeeper newHouseKeeper) {
		
		int result = this.houseKeeperDao.updateHouseKeeper(newHouseKeeper.getHouseKeeperId(),newHouseKeeper.getHouseKeeperName(),newHouseKeeper.getFloor(),
														newHouseKeeper.getHostelName(),newHouseKeeper.getRoomsCleaned(),	
														newHouseKeeper.getComplaints(),newHouseKeeper.getIsAvailable());
		
		if(result == 1)
			return newHouseKeeper;
		
		return null;
	}

	@Override
	public List<HouseKeeper> getAllHouseKeepers() {
		return this.houseKeeperDao.findAll();
	}

}
