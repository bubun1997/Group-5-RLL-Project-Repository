package com.mycompany.app.usercontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycompany.app.housekeeperservice.HouseKeeperService;
import com.mycompany.app.model.HouseKeeper;
import com.mycompany.app.model.User;
import com.mycompany.app.userservice.UserService;

@RestController
@RequestMapping("/api/user/myapp")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private HouseKeeperService houseKeeperService;
	
	@GetMapping("/get/all/housekeepers")
	public ResponseEntity<?> getAllHouseKeepers(){
		
		List<HouseKeeper> houseKeepers = this.houseKeeperService.getAllHouseKeepers();
		
		if(houseKeepers.isEmpty()) {
			
			return new ResponseEntity<String>("No housekeepers are avialble !!",HttpStatus.OK);
//			return null;
		}
		
		return new ResponseEntity<List<HouseKeeper>>(houseKeepers,HttpStatus.OK);
	}	
	
	@PostMapping("/register/user")
	public ResponseEntity<?> registerUser(@RequestBody User user){
		
		User addedUser = this.userService.saveUser(user);
		
		if(addedUser != null) {
			
			return new ResponseEntity<User>(addedUser,HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("User name is alreday taken !!",HttpStatus.OK);
	}
	
	@PostMapping("/user/login")
	public ResponseEntity<?> loginUser(@RequestBody User user){
		
		User myUser = this.userService.validateUserLogin(user.getUserName(), user.getUserPassword());
		if(myUser != null) {
			
			return new ResponseEntity<User>(myUser,HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Invalid credentials !!",HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("/update/user/password")
	public ResponseEntity<?> updatePassword(@RequestBody User user){
		
		int records = this.userService.updatePassword(user.getUserName(), user.getUserPassword());
		
		if(records != -1) {
			
			return new ResponseEntity<User>(user,HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("UserName doesn't exists !!",HttpStatus.BAD_REQUEST);
	}
	
}
