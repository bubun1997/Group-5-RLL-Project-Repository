package com.mycompany.app.housekeeperdao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mycompany.app.model.HouseKeeper;

@Repository
public interface HouseKeeperDao extends JpaRepository<HouseKeeper, Long>{

	@Query("UPDATE HouseKeeper hk set hk.houseKeeperName = ?2, hk.hostelName = ?4, hk.floor = ?3, "
					+ "hk.roomsCleaned = ?5, hk.complaints = ?6, "
					+ "hk.isAvailable = ?7 WHERE hk.houseKeeperId = ?1")
	@Modifying
	@Transactional
	int updateHouseKeeper(Long houseKeeperId, String houseKeeperName, int floor, String hostelName,
			int roomsCleaned, String complaints,String isAvailable);

	 
}
