package com.mycompany.app.housekeeperservice;

import java.util.List;

import com.mycompany.app.model.HouseKeeper;

public interface HouseKeeperService {

	
	List<HouseKeeper> getAllHouseKeepers();
	
	HouseKeeper findHoseKeeperById(Long id);
	
	HouseKeeper registerHouseKeeper(HouseKeeper houseKeeper);
	
	HouseKeeper updateHouseKeeper(HouseKeeper houseKeeper);
}
