package com.mycompany.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;



@Entity
@Table(name = "users")
public class User {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "uid")
	private Long userId;
	
	@Column(name = "name" , nullable = false,length = 255)
	private String fullName;
	
	@Column(name = "username" , unique = true, nullable = false,length = 100)
	private String userName;
	
	@Column(name = "userpassword" , nullable = false , length = 100)
	private String userPassword;
	
	@OneToMany(cascade = CascadeType.ALL , mappedBy = "user")
//	@JsonIgnore
	private List<HouseKeeper> housekeepers = new ArrayList<HouseKeeper>();

	public User() {
		super();
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@JsonManagedReference
	public List<HouseKeeper> getHousekeepers() {
		return housekeepers;
	}
	
	public void setHousekeepers(List<HouseKeeper> housekeepers) {
		this.housekeepers = housekeepers;
	}
	
	
    
	public void setHousekeepersForSpecificUser(HouseKeeper houseKeeper) {
		this.housekeepers.add(houseKeeper);
	}
	

	@Override
	public String toString() {
		return "User [userId=" + userId + ", fullName=" + fullName + ", userName=" + userName + ", userPassword="
				+ userPassword + ", housekeepers=" + housekeepers + "]";
	}
	
	
	
	

}
