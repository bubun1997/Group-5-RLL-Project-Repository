package com.mycompany.app.userservice;


import com.mycompany.app.model.User;

public interface UserService {

	 User validateUserLogin(String uname,String pass);
	 
	 User checkUserAvailability(String uname);
	
	 int updatePassword(String uname,String pass);
	 
	 User saveUser(User user);
	 
	 User findUserById(Long id);
}
