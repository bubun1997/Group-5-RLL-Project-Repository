package com.mycompany.app.userservice;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.app.model.User;
import com.mycompany.app.userdao.UserDao;

@Service
public class UserServiceImpl implements UserService {
  
	@Autowired
	private UserDao userDao;
	
	@Override
	public User validateUserLogin(String uname,String pass){
		
		return this.userDao.validateUserLogin(uname,pass);
	}
	
	@Override
	public int updatePassword(String uname,String pass) {
		
		User user = this.checkUserAvailability(uname);
		
		if(user != null) {
			
			return this.userDao.updatePassword(uname, pass);

			
		}
		return -1;
	}

	@Override
	public User saveUser(User user) {
		
		User availableUser = this.checkUserAvailability(user.getUserName());
		
		if(availableUser != null) {
			
			return null;
		}
		return  this.userDao.save(user);
	}

	@Override
	public User findUserById(Long id) {
		
		return this.userDao.findById(id).orElse(null);
	}

	@Override
	public User checkUserAvailability(String uname) {
		
		return this.userDao.checkUserAvilability(uname);
	}
	
	
	
	
}
