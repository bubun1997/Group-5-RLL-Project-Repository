package com.mycompany.app.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;




@Entity
@Table(name = "housekeepers")
public class HouseKeeper {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hid")
	private Long houseKeeperId;
	
	@Column(name = "hname" , nullable = false,length = 255)
	private String houseKeeperName;
	
	@Column(name = "hostelname", nullable = false,length = 255)
	private String hostelName;
	
	@Column(name = "floor",nullable = false,length = 5)
	private int floor;
	
	@Column(name = "roomscleaned",nullable = false,length = 5)
	private int roomsCleaned;
	
	@Column(name="available",nullable = false,length = 255)
	private String isAvailable;
	
	@Column(name = "complains")
	private String complaints;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "USERID",referencedColumnName = "uid")
	private User user;

	public HouseKeeper() {
		super();
	}

	public Long getHouseKeeperId() {
		return houseKeeperId;
	}

	public void setHouseKeeperId(Long houseKeeperId) {
		this.houseKeeperId = houseKeeperId;
	}

	public String getHouseKeeperName() {
		return houseKeeperName;
	}

	public void setHouseKeeperName(String houseKeeperName) {
		this.houseKeeperName = houseKeeperName;
	}

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public int getRoomsCleaned() {
		return roomsCleaned;
	}

	public void setRoomsCleaned(int roomsCleaned) {
		this.roomsCleaned = roomsCleaned;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getComplaints() {
		return complaints;
	}

	public void setComplaints(String complaints) {
		this.complaints = complaints;
	}

	@JsonBackReference
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "HouseKeeper [houseKeeperId=" + houseKeeperId + ", houseKeeperName=" + houseKeeperName + ", hostelName="
				+ hostelName + ", floor=" + floor + ", roomsCleaned=" + roomsCleaned + ", isAvailable=" + isAvailable
				+ ", complaints=" + complaints + "]";
	}

	

	
}
