import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { StudentLoginComponent } from './student-login/student-login.component';
import { RegisterComponent } from './register/register.component';
import { AllotComponent } from './allot/allot.component';
import { SuggestionsComponent } from './suggestions/suggestions.component';
import { RegisterStudentComponent } from './register-student/register-student.component';
import { RegisterHousekeeperComponent } from './register-housekeeper/register-housekeeper.component';
import { ComplaintsComponent } from './complaints/complaints.component';
import { RequestsComponent } from './requests/requests.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ProfileComponent } from './profile/profile.component';
import { StudentdashboardComponent} from './studentdashboard/studentdashboard.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';

const routes: Routes = [
  {path:'', redirectTo:'home', pathMatch:'full'},
  {path:'home', component:HomeComponent},
  {path:'about', component:AboutComponent},

  {path:'admin-login',component:AdminLoginComponent},
  {path:'student-login',component:StudentLoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'allot',component:AllotComponent},
  {path:'suggestions',component:SuggestionsComponent},
  {path:'register-student',component:RegisterStudentComponent},
  {path:'register-housekeeper',component: RegisterHousekeeperComponent},
  {path:'complaints',component: ComplaintsComponent},
  {path:'requests',component: RequestsComponent},
  {path:'feedback',component: FeedbackComponent},
  {path:'profile',component: ProfileComponent},
  {path:'studentdashboard',component: StudentdashboardComponent},
  {path:'admindashboard',component: AdmindashboardComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
