import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allot',
  templateUrl: './allot.component.html',
  styleUrls: ['./allot.component.css']
})
export class AllotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
