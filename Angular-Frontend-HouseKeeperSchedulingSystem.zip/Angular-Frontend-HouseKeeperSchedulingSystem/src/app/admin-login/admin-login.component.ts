import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  constructor(private router:Router) { }

  user: string="student";
  pass: string="12345";


  ngOnInit(): void {
  }

  authenticate(){
    if(this.user==="student" && this.pass==="12345"){
      this.router.navigate(['/admindashboard']);
    }
    else{
      alert("Incorrect username or password")
    }
  }

}
