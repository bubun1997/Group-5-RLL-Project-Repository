import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit {

  constructor(private router:Router) { }

  user: string = "Ravi";
  pass: string = "12345";

  ngOnInit(): void {
  }
  authenticate() {
    if(this.user=== "Ravi" && this.pass === "12345") {
      this.router.navigate(['/studentdashboard']);
    }
    else {
      alert("Incorrect username OR password!")
    }
  }

}
