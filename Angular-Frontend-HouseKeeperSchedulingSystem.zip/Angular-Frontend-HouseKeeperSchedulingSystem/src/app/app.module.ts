import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { CurdService } from './services/curd.service';
import { AboutComponent } from './about/about.component';
import { StudentLoginComponent } from './student-login/student-login.component';
import { RegisterComponent } from './register/register.component';
import { AllotComponent } from './allot/allot.component';
import { SuggestionsComponent } from './suggestions/suggestions.component';
import { RegisterStudentComponent } from './register-student/register-student.component';
import { RegisterHousekeeperComponent } from './register-housekeeper/register-housekeeper.component';
import { ComplaintsComponent } from './complaints/complaints.component';
import { RequestsComponent } from './requests/requests.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ProfileComponent } from './profile/profile.component';
import { StudentdashboardComponent } from './studentdashboard/studentdashboard.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AboutComponent,
    AdminLoginComponent,
    StudentLoginComponent,
    RegisterComponent,
    AllotComponent,
    SuggestionsComponent,
    RegisterStudentComponent,
    RegisterHousekeeperComponent,
    ComplaintsComponent,
    RequestsComponent,
    FeedbackComponent,
    ProfileComponent,
    StudentdashboardComponent,
    AdmindashboardComponent

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [CurdService],
  bootstrap: [AppComponent]
})
export class AppModule { }
