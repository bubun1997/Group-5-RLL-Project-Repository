import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-housekeeper',
  templateUrl: './register-housekeeper.component.html',
  styleUrls: ['./register-housekeeper.component.css']
})
export class RegisterHousekeeperComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
