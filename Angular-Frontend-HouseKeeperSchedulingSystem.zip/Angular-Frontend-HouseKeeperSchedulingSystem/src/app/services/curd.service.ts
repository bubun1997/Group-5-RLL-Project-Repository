import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class CurdService {

  constructor(private http: HttpClient) { }

  addStudent(formData: object) {
    return this.http.post(environment.baseURL + '/addstudent', formData);
  }

  viewStudents() {
    return this.http.get(environment.baseURL + '/getstudentlist');
  }

  deleteStudent(id: number) {
    console.log(environment.baseURL + '/deletestudentbyid/' + id)
    return this.http.delete(environment.baseURL + '/deletestudentbyid/' + id, { responseType: 'text' });
  }

  addFaculty(formData: object) {
    return this.http.post(environment.baseURL + '/addfaculty', formData);
  }
  viewFaculty() {
    return this.http.get(environment.baseURL + '/getfacultylist');
  }
  deleteFaculty(id: number) {
    console.log(environment.baseURL + '/deletefacultybyid/' + id)
    return this.http.delete(environment.baseURL + '/deletefacultybyid/' + id, { responseType: 'text' });
  }
  addLibrarian(formData: object) {
    return this.http.post(environment.baseURL + '/addlibrarian', formData);
  }
  viewLibrarian() {
    return this.http.get(environment.baseURL + '/getlibrarianlist');
  }
  deleteLibrarian(id: number) {
    console.log(environment.baseURL + '/deletelibrarianbyid/' + id)
    return this.http.delete(environment.baseURL + '/deletelibrarianbyid/' + id, { responseType: 'text' });
  }

  addAttendance(formData:Object){
    return this.http.post(environment.baseURL + '/addattendance', formData)
  }

  addAssignment(formData:Object){
    return this.http.post(environment.baseURL + '/addassignment', formData)
  }

  addResult(formData:Object){
    return this.http.post(environment.baseURL + '/addresult', formData)
  }
  viewAttendance() {
    return this.http.get(environment.baseURL + '/getAttendanceList');
  }
  viewAssignment() {
    return this.http.get(environment.baseURL + '/getAssignmentList');
  }
  viewResult() {
    return this.http.get(environment.baseURL + '/getResultList');
  }

}
